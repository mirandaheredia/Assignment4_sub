%% Part 4 - Transient Simulation
%% A) By inspection what kind of circuit is this?
% This appears to be an RLC circuit because there are capacitors, resistors
% and inductors. 
%% B) What frequency response should we expect?
%RLC circuits go through resonance at a certain frequqency
% (resonant frequency) and this is when then the capacitors and inductors
% are equal in magnitude and cancel each other out. At this frequency the gain of the circuit sharply rises, and is
%low at other frequencies. For this reason, this circuit has a very sharp
%lowpass response


clc
clear all

%Using stamps from ELEC 4506
global G C b;

G = zeros(5,5); 
C = zeros(5,5); 
b = zeros(5,1); 

R1 = 1;
C1 = 0.25;
R2 = 2;
L = 0.2;
R3 = 10;
a = 100;
R4 = 0.1;
R5 = 1000;

vol(1,0,1);
res(1,2,R1);
cap(1,2,C1);
res(2,0,R2);
ind(2,3,L);
vcvs(4,0,3,0,(a/R3));
res(3,0,R3);
res(4,5,R4);
res(5,0,R5);

%% Time Step Input 0 to 1 at 0.03s
%Using trapezoidal rule from ELEC 4506

h = 1/1000;
bn=zeros(length(b));
bn1=zeros(length(b));
xn=zeros(length(b));
time = linspace(0,1,1000);

for n=2:numel(time)
    pulse = in(1);
    %Trapezoidal Rule
    bn1(6) = pulse(n);
    bn(6) = pulse(n-1);
    trap =(2*C/h-G)*xn+bn1+bn;
    xn1=(2*C/h + G)\trap;
    Vout1(n) = xn(5)*2;
    xn = xn1;
    
    Vin(n-1) = xn(1);
    Vout(n-1) = xn(5);
end

Vin(n) = xn(1);
Vout(n) = xn(5);

figure(4)
subplot(3,1,1)
plot(time,Vin,time,Vout)
title('Pulse Input - Vin and Vout  W/ Time Step')
legend('Vin', 'Vout')
xlabel ('Time (ms)')
ylabel('Voltage (V)')
% Fourier
subplot(3,1,2)
plot(abs(fftshift(fft(Vin))))
title('FFT of Vin - Pulse Input')

subplot(3,1,3)
plot(abs(fftshift(fft(Vout))))
title('FFT of Vout - Pulse Input')

%% Sine Input

%Using trapezoidal rule from ELEC 4506
h = 1/1000;
bn=zeros(length(b));
bn1=zeros(length(b));
xn=zeros(length(b));
time = linspace(0,1,1000);

for n=2:numel(time)
    sinIn = in(2);
    %Trapezoidal Rule
    bn1(6) = sinIn(n);
    bn(6) = sinIn(n-1);
    trap =(2*C/h-G)*xn+bn1+bn;
    xn1=(2*C/h + G)\trap;
    Vout1(n) = xn(5)*2;
    xn = xn1;
     
    Vin(n-1) = xn(1);
    Vout(n-1) = xn(5);
end

Vin(n) = xn(1);
Vout(n) = xn(5);

figure(5)
subplot(3,1,1)
plot(time,Vin,time,Vout)
title('Sine Input - Vin and Vout')
legend('Vin', 'Vout')
xlabel ('Time (ms)')
ylabel('Voltage (V)')
% Fourier
subplot(3,1,2)
plot(abs(fftshift(fft(Vin))))
title('FFT of Vin - Sine Input')

subplot(3,1,3)
plot(abs(fftshift(fft(Vout))))
title('FFT of Vout - Sine Input')

%%  Gaussian Pulse Input

%Using trapezoidal rule from ELEC 4506

h = 1/1000;
bn=zeros(length(b));
bn1=zeros(length(b));
xn=zeros(length(b));
time = linspace(0,1,1000);

delay=0.06+(1-0.06)/2;

gdist=makedist('Normal','mu',delay,'sigma',0.03);
gpdf=pdf(gdist,time);
gpulse=gpdf/max(gpdf);

for n=2:numel(time)
    
    %Trapezoidal Rule
    bn1(6) = gpulse(n);
    bn(6) = gpulse(n-1);
    trap =(2*C/h-G)*xn+bn1+bn;
    xn1=(2*C/h + G)\trap;
    Vout1(n) = xn(5)*2;
    xn = xn1;
    
    Vin(n-1) = xn(1);
    Vout(n-1) = xn(5);
end

Vin(n) = xn(1);
Vout(n) = xn(5);

figure(6)
subplot(3,1,1)
plot(time,Vin,time,Vout)
title('Gaussian Pulse Input - Vin and Vout')
legend('Vin', 'Vout')
xlabel ('Time (ms)')
ylabel('Voltage (V)')

% Fourier
subplot(3,1,2)
plot(abs(fftshift(fft(Vin))))
title('FFT of Vin - Gaussian Pulse Input')
xlim([440 560])

subplot(3,1,3)
plot(abs(fftshift(fft(Vout))))
title('FFT of Vout - Gaussian Pulse Input')
xlim([440 560])

%% Increasing Time Step
% Increasing the time step decreases the accuracy of the model
% This is because for a bigger time step, the guess is going to be less
% accurate from FD method (trap)
