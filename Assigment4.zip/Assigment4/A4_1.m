%% Assignment 4 - Part 1
% This is an extension of PA 7

clear 
close all
%% A) G and C Matrices

global G C b

% initialize matrices
G = zeros(5,5);
C = zeros(5,5);
b = zeros(5,1);

%--------------------------------------------------------------------------
% List of the components (netlist):
%--------------------------------------------------------------------

% Part A) G and C matrices

R1 = 1;
C1 = 0.25;
R2 = 2;
L = 0.2;
R3 = 3.07;
a = 100;
R4 = 0.1;
R5 = 1000;

vol(1,0,1);
res(1,2,R1);
cap(1,2,C1);
res(2,0,R2);
ind(2,3,L);
vcvs(4,0,3,0,(a/R3));
res(3,0,R3);
res(4,5,R4);
res(5,0,R5);
disp('The G matix is:')
disp(G)
disp('The C matix is:')
disp(C)

%% B) DC Sweep

%sweeping the input voltage V1 from -10V to 10V
    
Vin = linspace(-10, 10, 50);
steps = 50;
for n = 1:steps
    b(6) = Vin(n);
    X = G\b;
    V3(n) = X(3);
    VO(n) = X(5);
    gain(n) = VO(n)/Vin(n);
end
figure(1)
plot(Vin, V3, Vin, VO);
legend('Voltage @ Node 3', 'Voltage @ Output');
xlabel('Vin')
title('Plot of DC Sweep')

%% B) AC Sweeps

% i) Plot AC sweep VO as a function of w(omega) and the gain
F = logspace(0,9,5000);
OutputNode = 5;
for n=1:length(F)
    w = 2*pi*F(n);
    s = 1i*F(n);
    A = G + (s*C);   

    X = A\b;
    Vout(n) = abs(X(OutputNode));
    gain(n) = 20*log(abs(X(OutputNode)));
end
figure(2);
semilogx(F, Vout);
xlabel('Frequency (Hz)');
ylabel('Vout (V)');
title('Frequncy Response')

%Gain Plot

figure(3);
semilogx(F, gain);
xlabel('Frequency (Hz)');
ylabel('Gain (dB)');
title('Gain Response');

% iii) Random Perturbations


Cs = 0.25 + 0.05*randn(1,1000);
for n = 1:1000
    s = 1i*pi;
    
    C(1,1) = Cs(n);
    C(2,2) = Cs(n);
    C(1,2) = Cs(n)*-1;
    C(2,1) = Cs(n)*-1;
    
    A = G +(s*C);
    X = A\b;
    gainP(n) = 20*log10(abs(X(OutputNode)));
end
figure(4)
histogram(gainP)

